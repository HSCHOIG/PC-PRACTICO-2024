﻿string nombre = "";
string edad = "";
string carrera = "";
string carne = "";

Console.WriteLine ("INGRESE UN NOMBRE: ");
Console.ReadLine (nombre);

Console.WriteLine ("INGRESE UNA EDAD: ");
Console.ReadLine (edad);

Console.WriteLine ("INGRESE UNA CARRERA: ");
Console.ReadLine (carrera);

Console.WriteLine ("INGRESE UN NUMERO DE CARNE: ");
Console.ReadLine (carne);

Console.WriteLine ("MI SEGUNDO PROGRAMA");
Console.WriteLine ("NOMBRE: " + nombre);
Console.WriteLine ("EDAD: " + edad);
Console.WriteLine ("CARRERA: " + edad);
Console.WriteLine ("CARNE: " + carne);

Console.WriteLine("Presione enter para continuar :D"):
Console.ReadKey();
Console.WriteLine("SOY " + nombre + ", TENGO " + edad + "ANIOS Y ESTUDIO LA CARRERA DE " + carrera + ". MI NUMERO DE CARNE ES; " + carne);
Console.ReadKey();